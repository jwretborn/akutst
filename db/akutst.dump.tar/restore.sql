--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.procedures DROP CONSTRAINT procedures_user_id_fkey;
ALTER TABLE ONLY public.procedures DROP CONSTRAINT procedures_procedure_type_fkey;
ALTER TABLE ONLY public.procedures DROP CONSTRAINT procedures_method_id_fkey;
ALTER TABLE ONLY public.procedures DROP CONSTRAINT procedures_anatomy_id_fkey;
ALTER TABLE ONLY public.procedure_types DROP CONSTRAINT procedure_types_method_group_fkey;
ALTER TABLE ONLY public.procedure_types DROP CONSTRAINT procedure_types_anatomy_group_fkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_user_id_fkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_triage_id_fkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_retts_id_fkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_age_id_fkey;
ALTER TABLE ONLY public.group_items DROP CONSTRAINT group_items_group_id_fkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.retts_codes DROP CONSTRAINT retts_codes_pkey;
ALTER TABLE ONLY public.procedures DROP CONSTRAINT procedures_pkey;
ALTER TABLE ONLY public.procedure_types DROP CONSTRAINT procedure_types_pkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_pkey;
ALTER TABLE ONLY public.groups DROP CONSTRAINT groups_pkey;
ALTER TABLE ONLY public.group_items DROP CONSTRAINT group_items_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.retts_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.procedures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.procedure_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.patients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.group_items ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.retts_codes_id_seq;
DROP TABLE public.retts_codes;
DROP SEQUENCE public.procedures_id_seq;
DROP TABLE public.procedures;
DROP SEQUENCE public.procedure_types_id_seq;
DROP TABLE public.procedure_types;
DROP SEQUENCE public.patients_id_seq;
DROP TABLE public.patients;
DROP SEQUENCE public.groups_id_seq;
DROP TABLE public.groups;
DROP SEQUENCE public.group_items_id_seq;
DROP TABLE public.group_items;
DROP TABLE public.alembic_version;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: jens
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO jens;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE alembic_version OWNER TO jens;

--
-- Name: group_items; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE group_items (
    id integer NOT NULL,
    group_id integer NOT NULL,
    name character varying(64) NOT NULL,
    weight integer NOT NULL
);


ALTER TABLE group_items OWNER TO jens;

--
-- Name: group_items_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE group_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE group_items_id_seq OWNER TO jens;

--
-- Name: group_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE group_items_id_seq OWNED BY group_items.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE groups (
    id integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE groups OWNER TO jens;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE groups_id_seq OWNER TO jens;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE groups_id_seq OWNED BY groups.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE patients (
    id integer NOT NULL,
    user_id integer NOT NULL,
    age_id integer NOT NULL,
    triage_id integer NOT NULL,
    retts_id integer,
    admittance boolean,
    tuition boolean,
    comments character varying(400),
    created date
);


ALTER TABLE patients OWNER TO jens;

--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE patients_id_seq OWNER TO jens;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE patients_id_seq OWNED BY patients.id;


--
-- Name: procedure_types; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE procedure_types (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    method_group integer,
    anatomy_group integer,
    show_success boolean,
    weight integer NOT NULL
);


ALTER TABLE procedure_types OWNER TO jens;

--
-- Name: procedure_types_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE procedure_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedure_types_id_seq OWNER TO jens;

--
-- Name: procedure_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE procedure_types_id_seq OWNED BY procedure_types.id;


--
-- Name: procedures; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE procedures (
    id integer NOT NULL,
    user_id integer NOT NULL,
    procedure_type integer NOT NULL,
    method_id integer,
    anatomy_id integer,
    tuition boolean,
    created date,
    successful boolean,
    comments character varying(400)
);


ALTER TABLE procedures OWNER TO jens;

--
-- Name: procedures_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE procedures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedures_id_seq OWNER TO jens;

--
-- Name: procedures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE procedures_id_seq OWNED BY procedures.id;


--
-- Name: retts_codes; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE retts_codes (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    code integer NOT NULL
);


ALTER TABLE retts_codes OWNER TO jens;

--
-- Name: retts_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE retts_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE retts_codes_id_seq OWNER TO jens;

--
-- Name: retts_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE retts_codes_id_seq OWNED BY retts_codes.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: jens; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    name character varying(32),
    username character varying(32)
);


ALTER TABLE users OWNER TO jens;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: jens
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO jens;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jens
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY group_items ALTER COLUMN id SET DEFAULT nextval('group_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY groups ALTER COLUMN id SET DEFAULT nextval('groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY patients ALTER COLUMN id SET DEFAULT nextval('patients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedure_types ALTER COLUMN id SET DEFAULT nextval('procedure_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedures ALTER COLUMN id SET DEFAULT nextval('procedures_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY retts_codes ALTER COLUMN id SET DEFAULT nextval('retts_codes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jens
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY alembic_version (version_num) FROM stdin;
\.
COPY alembic_version (version_num) FROM '$$PATH$$/2328.dat';

--
-- Data for Name: group_items; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY group_items (id, group_id, name, weight) FROM stdin;
\.
COPY group_items (id, group_id, name, weight) FROM '$$PATH$$/2336.dat';

--
-- Name: group_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('group_items_id_seq', 1, false);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY groups (id, name) FROM stdin;
\.
COPY groups (id, name) FROM '$$PATH$$/2330.dat';

--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('groups_id_seq', 1, false);


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY patients (id, user_id, age_id, triage_id, retts_id, admittance, tuition, comments, created) FROM stdin;
\.
COPY patients (id, user_id, age_id, triage_id, retts_id, admittance, tuition, comments, created) FROM '$$PATH$$/2342.dat';

--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('patients_id_seq', 1, false);


--
-- Data for Name: procedure_types; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY procedure_types (id, name, method_group, anatomy_group, show_success, weight) FROM stdin;
\.
COPY procedure_types (id, name, method_group, anatomy_group, show_success, weight) FROM '$$PATH$$/2338.dat';

--
-- Name: procedure_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('procedure_types_id_seq', 1, false);


--
-- Data for Name: procedures; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY procedures (id, user_id, procedure_type, method_id, anatomy_id, tuition, created, successful, comments) FROM stdin;
\.
COPY procedures (id, user_id, procedure_type, method_id, anatomy_id, tuition, created, successful, comments) FROM '$$PATH$$/2340.dat';

--
-- Name: procedures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('procedures_id_seq', 1, true);


--
-- Data for Name: retts_codes; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY retts_codes (id, name, code) FROM stdin;
\.
COPY retts_codes (id, name, code) FROM '$$PATH$$/2334.dat';

--
-- Name: retts_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('retts_codes_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jens
--

COPY users (id, name, username) FROM stdin;
\.
COPY users (id, name, username) FROM '$$PATH$$/2332.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jens
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: group_items_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY group_items
    ADD CONSTRAINT group_items_pkey PRIMARY KEY (id);


--
-- Name: groups_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: patients_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: procedure_types_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY procedure_types
    ADD CONSTRAINT procedure_types_pkey PRIMARY KEY (id);


--
-- Name: procedures_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY procedures
    ADD CONSTRAINT procedures_pkey PRIMARY KEY (id);


--
-- Name: retts_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY retts_codes
    ADD CONSTRAINT retts_codes_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: jens; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: group_items_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY group_items
    ADD CONSTRAINT group_items_group_id_fkey FOREIGN KEY (group_id) REFERENCES groups(id);


--
-- Name: patients_age_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_age_id_fkey FOREIGN KEY (age_id) REFERENCES group_items(id);


--
-- Name: patients_retts_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_retts_id_fkey FOREIGN KEY (retts_id) REFERENCES retts_codes(id);


--
-- Name: patients_triage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_triage_id_fkey FOREIGN KEY (triage_id) REFERENCES group_items(id);


--
-- Name: patients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: procedure_types_anatomy_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedure_types
    ADD CONSTRAINT procedure_types_anatomy_group_fkey FOREIGN KEY (anatomy_group) REFERENCES groups(id);


--
-- Name: procedure_types_method_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedure_types
    ADD CONSTRAINT procedure_types_method_group_fkey FOREIGN KEY (method_group) REFERENCES groups(id);


--
-- Name: procedures_anatomy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedures
    ADD CONSTRAINT procedures_anatomy_id_fkey FOREIGN KEY (anatomy_id) REFERENCES group_items(id);


--
-- Name: procedures_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedures
    ADD CONSTRAINT procedures_method_id_fkey FOREIGN KEY (method_id) REFERENCES group_items(id);


--
-- Name: procedures_procedure_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedures
    ADD CONSTRAINT procedures_procedure_type_fkey FOREIGN KEY (procedure_type) REFERENCES procedure_types(id);


--
-- Name: procedures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jens
--

ALTER TABLE ONLY procedures
    ADD CONSTRAINT procedures_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id);


--
-- PostgreSQL database dump complete
--

